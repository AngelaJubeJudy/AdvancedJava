package io.kimmking.dubbo.demo.api;

public interface UserService {

    User findById(int id);

}

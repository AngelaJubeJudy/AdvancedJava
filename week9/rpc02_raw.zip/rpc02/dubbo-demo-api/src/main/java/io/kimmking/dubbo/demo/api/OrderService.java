package io.kimmking.dubbo.demo.api;

public interface OrderService {

    Order findOrderById(int id);

}

package com.judy.mapper;
 
import java.util.List;
 
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
 
import com.judy.entity.OrderEntity;
 
public interface OrdersMapper {
	@Select("SELECT order_id as oid FROM orders ")
	public List<OrderEntity> findOrder();
 
	@Select("insert into orders(contract_number) values (#{contract_number}); ")
	public List<OrderEntity> insertUser(@Param("contract_number") String contract_number);
}

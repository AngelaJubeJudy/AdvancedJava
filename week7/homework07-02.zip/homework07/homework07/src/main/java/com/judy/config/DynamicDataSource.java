package com.judy.config;
// AbstractRoutingDataSource 类充当 DataSource 的路由中介, 能在运行时, 根据某种 key 来动态切换到真正的DataSource上
 
import java.util.HashMap;
import java.util.Map;
 
import javax.sql.DataSource;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;
 
@Component("dynamicDataSource")
@Primary
public class DynamicDataSource extends AbstractRoutingDataSource {
	Map<Object, Object> map = new HashMap<>();

	@Autowired
	@Qualifier("selectDataSource")
	private DataSource selectDataSource;
 
	@Autowired
	@Qualifier("updateDataSource")
	private DataSource updateDataSource;
 
	/**
	 * 返回生效的数据源名称
	 */
	@Override
	protected Object determineCurrentLookupKey() {
		System.out.println("DataSourceContextHolder：：：" + DataSourceContextHolder.getDbType());
		return DataSourceContextHolder.getDbType();
//		return DynamicDataSourceHolder.getDataSource();
	}

	@Override
	protected Object resolveSpecifiedLookupKey(Object lookupKey) {
		return super.resolveSpecifiedLookupKey(lookupKey);
	}
 
	/**
	 * 配置数据源
	 */
	@Override
	public void afterPropertiesSet() {
		
		map.put("selectDataSource", selectDataSource);
		map.put("updateDataSource", updateDataSource);
		setTargetDataSources(map);
		setDefaultTargetDataSource(updateDataSource);
		super.afterPropertiesSet();

	}
}

package com.judy.config;
 
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
 
@Component
@Lazy(false)
public class DataSourceContextHolder {
	// ThreadLocal 保存本地多数据源
	private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();
 
	public static void setDbType(String dbType) {
		contextHolder.set(dbType);
	}
 
	public static String getDbType() {
		return contextHolder.get();
	}
 
	public static void clearDbType() {
		contextHolder.remove();
	}
 
}

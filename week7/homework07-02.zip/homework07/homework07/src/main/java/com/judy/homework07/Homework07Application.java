package com.judy.homework07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Homework07Application {

	public static void main(String[] args) {
		SpringApplication.run(Homework07Application.class, args);
	}

}

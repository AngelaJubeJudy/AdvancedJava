package com.judy.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.boot.context.properties.EnableConfigurationProperties;


@Configuration
@Import(WebConfiguration.class)
@EnableConfigurationProperties(WebProperties.class)
public class WebAutoConfiguration {

    @Autowired
    WebConfiguration conf;

    @Autowired
    WebProperties prop;

    @Bean
    public WebInfo createInfo(){
        return new WebInfo(conf.name + "---" + prop.getName());
    }

}

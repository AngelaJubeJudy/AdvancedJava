package com.judy.democlass;

import com.judy.democlass.ISchool;
import com.judy.democlass.Student;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;

@Data
public class School implements ISchool {

    // ����ʱ����װ�أ�Ĭ�ϰ�����ע��
    @Autowired(required = true)
    Klass class1;

    // Ĭ�ϰ�����ע��
    @Resource(name = "student0002")
    Student student100;
    
    @Override
    public void ding(){
    
        System.out.println("Class1 have " + this.class1.getStudents().size() + " students and one is " + this.student100);
        
    }
    
}

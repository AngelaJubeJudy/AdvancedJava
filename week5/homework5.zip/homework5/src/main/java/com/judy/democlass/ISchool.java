package com.judy.democlass;

public interface ISchool {
    
    void ding();
    
}

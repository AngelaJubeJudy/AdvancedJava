package com.judy.democlass;

import java.text.DateFormat;
import java.util.*;

import com.judy.democlass.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        Date start = new Date();
        DateFormat d = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG);
        System.out.println("---------START PROJECT05: " + d.format(start) + "---------");

        Student st1 = new Student();
        st1.setId(0001);
        st1.setName("student0001");
        System.out.println("Student name: " + st1.getName());

        School sch1 = new School();
        Klass cls1 = new Klass();
        Student st2 = new Student(0002, "student0002", sch1, cls1);
        System.out.println("Student name: " + st2.getName());

        // ��ļ���װ��
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        Student student01 = (Student) context.getBean("student0002");
        System.out.println(student01.toString());
        student01.print();

        Date end = new Date();
        System.out.println("---------END PROJECT05: " + d.format(end) + "---------");
    }
}

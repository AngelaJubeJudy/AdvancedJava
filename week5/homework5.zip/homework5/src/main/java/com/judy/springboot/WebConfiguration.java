package com.judy.springboot;

import org.springframework.context.annotation.Configuration;


@Configuration
public class WebConfiguration {
    public String name = "Spring Boot Web Configuration";
}

package com.judy.springboot;

public class WebInfo {
    private String name;

    public WebInfo(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void setName(String inp){
        this.name = inp;
    }
}

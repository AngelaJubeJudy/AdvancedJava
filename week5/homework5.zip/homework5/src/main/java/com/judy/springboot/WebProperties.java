package com.judy.springboot;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix="web")
public class WebProperties {
    private String test = "test";

    public String getName(){
        return test;
    }

    public void setName(String inp){
        this.test = inp;
    }
}

package com.judy.democlass;

import com.judy.democlass.Student;
import lombok.Data;

import java.util.List;

@Data
public class Klass { 
    
    List<Student> students;
    
    public void dong(){
        System.out.println(this.getStudents());
    }

    public List<Student> getStudents() {
//        for(int i = 0; i < 4; i++){
//            this.students.add(new Student(i, "student_" + Integer.toString(i), null, null));
//        }
        return this.students;
    }

}

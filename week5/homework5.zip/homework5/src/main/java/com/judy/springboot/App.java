package com.judy.springboot;


import org.springframework.boot.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class App {
    public static void main(String[] args){
        SpringApplication.run(App.class, args);
    }

    @Autowired
    WebInfo webInfo;

    @Bean
    public void printInfo(){
        System.out.println(webInfo.getName());
    }
}

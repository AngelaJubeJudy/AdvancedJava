package com.judy.democlass;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.io.Serializable;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Student implements Serializable, BeanNameAware, ApplicationContextAware {

    private int id;
    private String name;
    private School school;
    private Klass klass;

    private String beanName;
    private ApplicationContext applicationContext;

    public Student(int i, String kk101) {
        this.id = i;
        this.name = kk101;
    }

    public Student(int i, String kk102, Object o, Object o1) {
        this.id = i;
        this.name = kk102;
        this.school = (School)o;
        this.klass = (Klass) o1;
    }

    public Student() {

    }

    public void init(){
        System.out.println("initiate now...........");
    }
    
    public static Student create(){
        return new Student(102, "KK102", null, null);
    }

    public void print() {
        System.out.println(this.beanName);
        System.out.println("   context.getBeanDefinitionNames() ===>> "
                + String.join(",", applicationContext.getBeanDefinitionNames()));

    }


    @Override
    public void setBeanName(String s) {

    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

    }

    public void setId(int i) {
        this.id = i;
    }

    public void setName(String kk01) {
        this.name = kk01;
    }

    public String getName() {
        return this.name;
    }
}
